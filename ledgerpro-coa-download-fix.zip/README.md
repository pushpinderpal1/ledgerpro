# Hotfix: COA template download

Replaces existing `src/app/page.tsx` only.

## The fix

`window.open('/api/accounts/import?template=csv')` was opening a new tab
that the auth middleware would either redirect or block depending on
cookie behavior, browser policy, and pop-up settings.

Replaced with a client-side Blob download — the template content is
embedded directly in the component, builds a Blob, creates an invisible
`<a download>` link, clicks it, then cleans up. No network call, no
auth, no pop-up blocker.

## Deploy

```
git add src/app/page.tsx
git commit -m "Fix COA template download"
git push
```

No migrations, no env vars, no dependencies.

## Testing after deploy

1. Hard-refresh the app (Ctrl+Shift+R / Cmd+Shift+R)
2. Go to Accounts → click "↥ Import COA"
3. Click "Download template" link in the modal
4. Your browser downloads `ledgerpro-coa-template.csv` immediately
5. Open it in Excel / Numbers / a text editor — should contain 12 sample
   accounts with the header row

If it still doesn't download after the hard-refresh, that means the
deploy didn't pick up the change — check Railway's Deployments tab to
confirm the latest commit ("Fix COA template download") built successfully.
