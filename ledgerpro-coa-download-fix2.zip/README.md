# Hotfix #2: COA template download — pure HTML anchor

Replaces only `src/app/page.tsx`.

## What changed

The previous fix used `Blob` + `URL.createObjectURL` + a click on a
dynamically created `<a>` element. That should have worked but didn't,
on your setup.

This version drops to the simplest possible mechanism: **a plain
`<a href="data:text/csv;..." download="...">` link** with the entire
template content embedded as a data URI.

- No JavaScript function call
- No event handler
- No Blob API
- No URL.createObjectURL
- No middleware involvement
- No pop-up blocker can touch it
- Right-click → "Save link as" works even if click somehow doesn't

It's the same mechanism browsers use for every HTML download link on the
web. If this doesn't work, the browser itself is broken.

## Deploy

```
cd C:\ledgerpro
# extract the zip first, overwriting src\app\page.tsx
git add src/app/page.tsx
git commit -m "Hotfix: COA template via data-URI anchor"
git push
```

Wait for Railway to build (check Deployments tab — top entry should
match your commit and be green).

## Testing

1. **Hard refresh**: Ctrl+Shift+R (Windows) or Cmd+Shift+R (Mac)
2. Open the app → Accounts → ↥ Import COA
3. Click "Download template"
4. Browser downloads `ledgerpro-coa-template.csv` immediately

If clicking still does nothing:

1. **Right-click** the "Download template" link → "Save link as..."
   This bypasses any onClick handling entirely. If it downloads this
   way, your browser had a click handler problem (extension, etc.).
2. If even right-click → Save link as doesn't work, your browser is
   blocking data URI downloads. Edge, Chrome, Firefox all support this
   by default — there's no realistic scenario where this would fail
   unless an extension or enterprise security policy is blocking it.

## If it still doesn't work

Open browser DevTools (F12), go to Console tab, hard-refresh the page,
open the modal, click the link. Paste any red errors from the console
here and I'll have a precise answer in one round.
